from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
target = root / 'dist' / 'Kokalanov_Bridge_Lab_v1.zip'
files = [root / name for name in ('README.md', 'METHODS.md', 'launch.py', 'START_WINDOWS.bat', 'package.json', 'package_source.py', 'VALIDATION.md')]
files += list((root / 'dist').rglob('*')) + list((root / 'tests').rglob('*'))
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in files:
        if file.is_file() and file != target and not file.name.endswith('.zip'):
            archive.write(file, 'Kokalanov_Bridge_Lab/' + file.relative_to(root).as_posix())
print(f'{target} ({target.stat().st_size:,} bytes)')
