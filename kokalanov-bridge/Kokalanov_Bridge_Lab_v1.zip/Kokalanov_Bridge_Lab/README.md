# Kokalanov Bridge Lab — v1.0

A personal, witty bridge experiment built for Fatih. Real planar truss calculations, an interactive 3D scene and a stricter fictional Kokalanov inspection. The professor's comments are original fictional project copy, not quotations or endorsement.

## Run

No account, API key, npm install or compilation is needed to run the downloaded site. Run `START_WINDOWS.bat` on Windows with Python installed, or `python3 launch.py` on macOS/Linux. The launcher serves the included `dist` folder and opens the browser. Opening index.html directly as a file does not support browser modules.

## Implemented

- Turkish, English and Macedonian. `?lang=mk` selects the professor-facing language.
- Local Three.js 0.180.0 assets; no CDN, analytics or third-party runtime requests.
- Warren, Pratt and Howe planar bridge topologies, geometry and bar diameter controls.
- Member inspection, removal/restoration, adding members between joints, and pin/roller support editing.
- Real stiffness-matrix assembly, stable-system solving, dead weight, vehicle interpolation and in-plane horizontal load.
- Axial stress, ideal single-bar Euler buckling, static displacement and first natural frequency.
- A 12-second quasi-static vehicle crossing and a separate first-mode free-vibration experiment.
- A fixed 60× visual displacement scale for ordinary results, reduced and labelled for extreme displacement. Numeric measurements are unamplified.
- Honest singular/mechanism detection. A removed stabilising member does not produce fabricated measurements.
- Transparent normal/strict experiment rules. A sufficiently strong design really passes.
- Saved designs in browser storage, two-design comparisons, JSON import/export and URL-based design sharing.
- CSV export, branded PNG capture, printable report, downloadable source.
- A perspective Canvas 3D fallback with orbit, selection, editing and image export when WebGL is unavailable. A basic 2D fallback is retained for the rare case where neither renderer starts.

Saved designs stay in the current browser. Use JSON or a design link to transfer them. There is no multi-user cloud database. Data is not sent to the professor or Instagram.

## Verify

With Node.js installed, run `npm test`. Tests use built-in Node tools and check exact axial-bar and triangular-truss solutions, scaling/energy identities, equilibrium under non-nodal moving loads, singular mechanisms, natural-mode convergence, topology stability and pass/fail inspection behaviour.

## Physical scope

Read METHODS.md. This is an idealised, linear planar experiment, not an engineering certification tool. Loads on the two visible sides are split consistently. The model does not reproduce nonlinear collapse, global buckling, full bridge dynamics or an earthquake.

## Source

`dist/physics.mjs`: numerical engine. `dist/scene.mjs`: 3D view. `dist/app.mjs`: interactions, storage and exports. `dist/i18n.mjs`: translations. `tests/physics.test.mjs`: independent calculation oracles.

Three.js is MIT licensed; its notice is in `dist/vendor/THREE-LICENSE.txt`.
